package main;

import java.util.ArrayList;

public class Factory {
	double x,y;
	double direction;
	double frequency; //this is the interval between cars being created
	ArrayList<Vehicle> modelvehicles; //vehicles to choose from
	Start s;
	int amount;
	double timesincecreate;
	Waypoints wp;
	int curid;
	public Factory(Start s,Waypoints wp1){
		modelvehicles = new ArrayList<Vehicle>();
		this.s = s;
		wp = wp1;
		curid=0;
		amount =1;
	}
	public void update(){
		int delta = s.getDelta();
		timesincecreate += ((double)delta)/1000.0f;
		int numcars = (int)(timesincecreate/frequency);
		timesincecreate -= (numcars)*frequency;
		if(timesincecreate<0){
			timesincecreate = 0;
		}
		
		if(numcars!=0&&!(amount<=0)){
			System.out.println("we have a new car because numcars = " +numcars + " x = " + x + " and y = " + y);
			Vehicle v;
			v = modelvehicles.get((int)Math.random()*modelvehicles.size());
			if(v.getClass()==(new Car(v)).getClass()){
				Car newcar = new Car(x,y,v.w,v.h,direction,v.maxspeed,v.col,wp,s,v.steer,curid);
				System.out.println(newcar);
				s.vehicles.add(newcar);
			}else {
				s.vehicles.add(new Bus(x,y,v.w,v.h,direction,v.maxspeed,v.col,wp,s,v.steer,curid));
			}
			curid++;
			amount--;
		}

	}
	
}
