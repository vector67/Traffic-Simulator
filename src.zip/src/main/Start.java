package main;

import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.ArrayList;

import org.lwjgl.*;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.*;
//import org.lwjgl.opengl.GL


public class Start {
	long lastFPS,fps;
	ArrayList<Vehicle> vehicles;
	Vehicle v;
	boolean adown,sdown,wdown,ddown;
	long lastFrame;
	int delta;
	Waypoints wp;
	ArrayList<Bucket> buckets;
	URL pngURL;
	boolean leftHeld = false, rightHeld = false;
    boolean upHeld = false, downHeld = false;

    //vehicle controls
    float steering = 0; //-1 is left, 0 is center, 1 is right
    float throttle = 0; //0 is coasting, 1 is full throttle
    float brakes = 0; //0 is no brakes, 1 is full brakes
	public static double distance(double x1,double y1,double x2,double y2){
		return (double)Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	}
	public static double dirto(double x1,double y1,double x2,double y2){
		double rise = y2-y1;
		double run = x2-x1;
		double poss = 0;
		if(run<0){
			poss = (double)Math.PI;
		}
		if(((double)Math.atan(rise/run)+poss)>Math.PI)
			return (double)(Math.atan(rise/run)+poss-Math.PI*2);
		return (double)Math.atan(rise/run)+poss;
	}
	private void ProcessInput()
    {
        if (leftHeld)
            steering = -1;
        else if (rightHeld)
            steering = 1;
        else
            steering = 0;

        if (upHeld)
            throttle = 1;
        else
            throttle = 0;

        if (downHeld)
            brakes = 1;
        else
            brakes = 0;
    }
    public void start() {

    	//texturesetup();
    	buckets = new ArrayList<Bucket>();
    	//for(int i = 0;i<4;i++){
    		//for(int y)
    		//buckets.add(new Bucket(1,1,1,1));
    //	}
    	updatedelta();
    	wp = new Waypoints();
    	wp.add(new Node(180f,150f));  	
    	wp.add(new Node(130f,180f));  	
    	wp.add(new Node(100f,260f));  	
    	wp.add(new Node(85f,340f));  	
    	wp.add(new Node(75f,420f));  	
    	wp.add(new Node(73f,500f));
    	wp.add(new Node(75f,580f)); 	
    	wp.add(new Node(85f,660f)); 
    	wp.add(new Node(100f,740f));  	
    	wp.add(new Node(130f,820f));  	
    	wp.add(new Node(180f,900f));  	
    	wp.add(new Node(240f,920f));  	
    	wp.add(new Node(300f,920f));  	
    	wp.add(new Node(400f,920f));  	
    	wp.add(new Node(500f,920f));  	
    	wp.add(new Node(580f,900f));  	
    	wp.add(new Node(640f,860f));  	
    	wp.add(new Node(680f,800f));  	
    	wp.add(new Node(700f,720f));  	
    	wp.add(new Node(700f,520f));  	
    	wp.add(new Node(680f,460f));  	
    	wp.add(new Node(640f,390f));  	
    	wp.add(new Node(580f,340f));  	
    	wp.add(new Node(500f,270f));  	
    	wp.add(new Node(400f,240f));  	
    	wp.add(new Node(300f,180f));  	
    	wp.add(new Node(240f,150f));  	
    	wp.add(new Node(180f,150f));
    	
    	Factory f = new Factory(this,wp);
    	f.direction = (double)Math.PI/2f;
    	f.x = 200;
    	f.y = 150;
    	f.frequency = 0.25f;
    	f.modelvehicles.add(new Car(0,0,30,15,0,240,new Color(0.4f,0.8f,0.2f),wp,this,50));
        try {
		    Display.setDisplayMode(new DisplayMode(1024, 768));
		    Display.create();
		} catch (LWJGLException e) {
		    e.printStackTrace();
		    System.exit(0);
		}
        vehicles = new ArrayList<Vehicle>();
        
        lastFPS = getTime();
     // init OpenGL
    	GL11.glMatrixMode(GL11.GL_PROJECTION);
    	GL11.glLoadIdentity();
    	GL11.glOrtho(0, 1280, 0, 1024, 1, -1);
    	GL11.glMatrixMode(GL11.GL_MODELVIEW);
    	
	    while (!Display.isCloseRequested()) {
	    // render OpenGL here
	    	// Clear the screen and depth buffer
		    GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);	
		    ProcessInput();
		    //apply vehicle controls

		    updateFPS();
		    updatedelta();
		    drawCars();
		    f.update();
		    pollInput();
		    for(Vehicle v: vehicles){
	        	if(v!=null){
	        		v.update();
	        	}
	        }
		    //System.out.println(((double)getDelta())/1000f);
		    Display.update();
		   Display.sync(480);
		}
	
		Display.destroy();
    }
    /**
     * Get the time in milliseconds
     * 
     * @return The system time in milliseconds
     */
    public long getTime() {
        return (Sys.getTime() * 1000) / Sys.getTimerResolution();
    }
    public void updatedelta(){
    	long time = getTime();
        int d = (int) (time - lastFrame);
        lastFrame = time;
        this.delta = d;
    }
    public int getDelta() {
        
        return this.delta;
    }
    /**
     * Calculate the FPS and set it in the title bar
     */
    public void updateFPS() {
        if (getTime() - lastFPS > 1000) {
            Display.setTitle("FPS: " + fps); 
            fps = 0; //reset the FPS counter
            lastFPS += 1000; //add one second
        }
        fps++;
    }
    public void pollInput() {
		
        if (Mouse.isButtonDown(0)) {
		    int x = Mouse.getX();
		    int y = Mouse.getY();
				
		    System.out.println("MOUSE DOWN @ X: " + x + " Y: " + y);
		}
			
		if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
		    System.out.println("SPACE KEY IS DOWN");
		}
			
		while (Keyboard.next()) {
		    if (Keyboard.getEventKeyState()) {
		        if (Keyboard.getEventKey() == Keyboard.KEY_A) {
				    System.out.println("A Key Pressed");
				    leftHeld = true;
				}
				if (Keyboard.getEventKey() == Keyboard.KEY_S) {
				    System.out.println("S Key Pressed");
				    downHeld = true;
				}
				if (Keyboard.getEventKey() == Keyboard.KEY_D) {
				    System.out.println("D Key Pressed");
				    rightHeld = true;
				}
				if (Keyboard.getEventKey() == Keyboard.KEY_W) {
				    System.out.println("W Key Pressed");
				    upHeld = true;
				}
		    } else {
		        if (Keyboard.getEventKey() == Keyboard.KEY_A) {
		        	System.out.println("A Key Released");
		        	leftHeld = false;
		        }
		    	if (Keyboard.getEventKey() == Keyboard.KEY_S) {
		    		System.out.println("S Key Released");
		    		downHeld = false;
		    	}
				if (Keyboard.getEventKey() == Keyboard.KEY_D) {
				    System.out.println("D Key Released");
				    rightHeld = false;
				}
				if (Keyboard.getEventKey() == Keyboard.KEY_W) {
				    System.out.println("W Key Released");
				    upHeld = false;
				}
		    }
		}
    }
    void glCircle3i(double x, double y, double radius) { 
        double angle; 
        GL11.glPushMatrix(); 
        GL11.glLoadIdentity(); 
        GL11.glDisable(GL11.GL_TEXTURE_2D); 
        GL11.glColor3f(0.0f, 1.0f, 0.0f); 
        GL11.glLineWidth(1.0f); 
        GL11.glBegin(GL11.GL_LINE_LOOP); 
        for(int i = 0; i < 100; i++) { 
            angle = i*2*Math.PI/100; 
            GL11.glVertex2d(x + (Math.cos(angle) * radius), y + (Math.sin(angle) * radius)); 
        } 
        GL11.glEnd(); 
        GL11.glEnable(GL11.GL_TEXTURE_2D); 
        GL11.glPopMatrix(); 
    }  
    public void drawCars(){
    	GL11.glColor3f(0.5f,0.5f,0.5f);
		GL11.glLineWidth(10f);
	    GL11.glBegin(GL11.GL_LINES);
    	for(Node n:wp){
		    /*GL11.glVertex2d(n.x+2f,n.y+2f);
			GL11.glVertex2d(n.x-2,n.y+2);
			GL11.glVertex2d(n.x-2,n.y-2);
			GL11.glVertex2d(n.x+2,n.y-2);*/
    		//System.out.println(GL11.glGetFloat(GL11.GL_LINE_WIDTH_RANGE));
			GL11.glVertex2d(n.x,n.y);
			GL11.glVertex2d(wp.next(n).x,wp.next(n).y);
    	}
	    GL11.glEnd();
		GL11.glColor3f(1f,1f,1f);
		GL11.glLineWidth(2f);
	    GL11.glBegin(GL11.GL_LINES);
    	for(Node n:wp){
		    /*GL11.glVertex2d(n.x+2f,n.y+2f);
			GL11.glVertex2d(n.x-2,n.y+2);
			GL11.glVertex2d(n.x-2,n.y-2);
			GL11.glVertex2d(n.x+2,n.y-2);*/
    		//System.out.println(GL11.glGetFloat(GL11.GL_LINE_WIDTH_RANGE));
			GL11.glVertex2d(n.x,n.y);
    	}
	    GL11.glEnd();
	    

    	for(Vehicle v:vehicles){
    		// draw quad
    		if(v!=null){
    			GL11.glColor4f((float)v.col.getRed()/255,(float)v.col.getGreen()/255,(float)v.col.getBlue()/255,((v.col.getAlpha())/255f));
    			GL11.glBegin(GL11.GL_QUADS);
			    GL11.glVertex2f((float)(v.x + ( v.w / 2 ) * Math.cos( v.angle )- ( v.h / 2 ) * Math.sin( v.angle )),(float)(  v.y + ( v.h / 2 ) * Math.cos (v.angle)  + ( v.w / 2 ) * Math.sin (v.angle)));
				GL11.glVertex2f((float)(v.x - ( v.w / 2 ) * Math.cos( v.angle )- ( v.h / 2 ) * Math.sin( v.angle )),(float)(  v.y + ( v.h / 2 ) * Math.cos (v.angle)  - ( v.w / 2 ) * Math.sin (v.angle)));
				GL11.glVertex2f((float)(v.x - ( v.w / 2 ) * Math.cos( v.angle )+ ( v.h / 2 ) * Math.sin( v.angle )),(float)(  v.y - ( v.h / 2 ) * Math.cos (v.angle)  - ( v.w / 2 ) * Math.sin (v.angle)));
				GL11.glVertex2f((float)(v.x + ( v.w / 2 ) * Math.cos( v.angle )+ ( v.h / 2 ) * Math.sin( v.angle )),(float)(  v.y - ( v.h / 2 ) * Math.cos (v.angle)  + ( v.w / 2 ) * Math.sin (v.angle)));
			    GL11.glEnd();
    		}
    	}
    }
    public static void main(String[] argv) {
        Start st = new Start();
        st.start();
    }
}