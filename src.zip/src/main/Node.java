package main;

public class Node {
	public double x,y;
	public Node(double x1, double y1){
		x=x1;
		y=y1;
	}
}
