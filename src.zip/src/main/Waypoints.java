package main;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Waypoints implements Collection<Node> {
	ArrayList<Node> nodes;
	public Waypoints(){
		nodes = new ArrayList<Node>();
	}
	@Override
	public boolean add(Node arg0) {
		return nodes.add(arg0);
	}

	@Override
	public boolean addAll(Collection<? extends Node> arg0) {
		return nodes.addAll(arg0);
	}

	@Override
	public void clear() {
		nodes.clear();
		
	}

	@Override
	public boolean contains(Object arg0) {
		return nodes.contains(arg0);
	}

	@Override
	public boolean containsAll(Collection<?> arg0) {
		return nodes.containsAll(arg0);
	}
	public Node get(int index){
		return nodes.get(index);
	}
	@Override
	public boolean isEmpty() {
		return nodes.isEmpty();
	}

	@Override
	public Iterator<Node> iterator() {
		return nodes.iterator();
	}
	public Node next(Node obj){
		int ind = nodes.indexOf(obj)+1;
		if(ind<nodes.size()){
			return nodes.get(ind);
		} else {
			return nodes.get(0);
		}
	}
	public Node prev(Node obj){
		int ind = nodes.indexOf(obj)-1;
		if(ind<0){
			return nodes.get(ind);
		} else {
			return null;
		}
	}
	@Override
	public boolean remove(Object arg0) {
		return nodes.remove(arg0);
	}

	@Override
	public boolean removeAll(Collection<?> arg0) {
		return nodes.removeAll(arg0);
	}

	@Override
	public boolean retainAll(Collection<?> arg0) {
		return nodes.retainAll(arg0);
	}

	@Override
	public int size() {
		return nodes.size();
	}

	@Override
	public Object[] toArray() {
		return nodes.toArray();
	}

	@Override
	public <T> T[] toArray(T[] arg0) {
		return nodes.toArray(arg0);
	}

}
