package main;

import java.util.ArrayList;

public class Bucket extends Node{
	ArrayList<Vehicle> vhcls;
	int width,height;
	public Bucket(double x1, double y1,int w,int h) {
		super(x1, y1);
		width = w;
		height = h;
	}
	public boolean isPointIn(int x1,int y1){
		return (x1<(x+width/2)&&x1>(x-width/2)&&y1<(y+height/2)&&y1>(y-height/2));
	}
}
