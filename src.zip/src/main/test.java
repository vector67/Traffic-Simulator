package main;

public class test {
	public static double dirto(double x1,double y1,double x2,double y2){
		double rise = y2-y1;
		double run = x2-x1;
		double poss = 0;
		if(run<0){
			poss = (double)Math.PI;
		}
		System.out.println(poss);
		if(((double)Math.atan(rise/run)+poss)>Math.PI)
			return (double)(Math.atan(rise/run)+poss-Math.PI*2);
		return (double)Math.atan(rise/run)+poss;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Math.toDegrees(dirto(200,50,100,100)));
	}

}
