package main;

import java.awt.Color;

import org.lwjgl.opengl.GL11;
import org.newdawn.slick.geom.Vector2f;


public abstract class Vehicle{
	public int bucketx;
	public int buckety;
	public double x,y;
	public int w,h;
	public double angle,speed,steer,maxspeed,braking;
	public double tcx,tcy,tcr; //turning circle vars
	double Mtocentercirc = 0,Ctocentercirc = 0,Mmiddleline = 0,Cmiddleline = 0,oldx,oldy;
	public double adddelta;
	double secs,circ,radius;
	public Color col;
	public Waypoints waypts;
	public Node current;
	public int ID;
	Start st;
	public Vehicle(double x1,double y1,int w1,int h1,double a1,double s1,Color col2,Waypoints wp,Start st1,double steer,int id){
		this(x1,y1,w1,h1,a1,s1,col2,wp,st1,steer);
		ID = id;
	}
	public Vehicle(double x1,double y1,int w1,int h1,double a1,double s1,Color col2,Waypoints wp,Start st1,double steer1){
		//super();
		//super.Setup(new Vector2f(4,2), 1, new Color(1f,1f,1f),new Vector2f((float)x1,(float)y1));
		x=x1;
		y=y1;
		w=w1;
		h=h1;
		angle=a1;
		maxspeed=s1;
		speed = 0.1;
		col = col2;
		waypts = wp;
		steer = steer1;
		st = st1;
		if(!wp.isEmpty()){
			current = wp.get(0);
			angle = Start.dirto(x, y, current.x, current.y);
			
		}
	}
	public Vehicle(Vehicle v){
		this(v.x,v.y,v.w,v.h,v.angle,v.maxspeed,v.col,v.waypts,v.st,v.steer,v.ID);
	}
	public void update(){
		adddelta += st.getDelta()/1000f;
		if(adddelta>1){
			System.out.println(toString());
			adddelta = 0;
		}
		//AddForce(new Vector2f(100f,0f),RelativeToWorld(new Vector2f(1f,3f)));
		//super.Update(st.getDelta()/1000.0f);
		//System.out.println(st.getDelta()/1000.0f);
		double directionto = Start.dirto(x, y, current.x, current.y);
		if(current!=null){
			if(Start.distance(x,y,current.x,current.y)<(speed*((double)st.getDelta())/1000f)*1.1){
				oldx = x;
				oldy = y;
				Mtocentercirc = 0;
				Ctocentercirc = 0;
				Mmiddleline = 0;
				Cmiddleline = 0;
				braking = 0;
				current = waypts.next(current);
				if(ID==0){
					System.out.println("Reached node, going towards node " + current.x +","+current.y);
				}
				//directionto = Start.dirto(x, y, current.x, current.y);
				if(directionto>Math.PI){ //somethings funny
					recadjustangle(directionto,0);
				}
				secs = 360/steer;
				circ = speed*secs;
				radius = (circ/Math.PI)/2;
				double addninety = 0;
				double centerx,centery,centerx1,centery1;
				if(directionto>angle){
					addninety = Math.PI/2;
				}else {
					addninety = -Math.PI/2;
				}
				centerx1 = Math.cos(angle+Math.PI/2)*radius+x;
				centery1 = Math.sin(angle+Math.PI/2)*radius+y;
				centerx = Math.cos(angle-Math.PI/2)*radius+x;
				centery = Math.sin(angle-Math.PI/2)*radius+y;

				if(Start.distance(centerx, centery, current.x, current.y)<radius||Start.distance(centerx1, centery1, current.x, current.y)<radius){
					System.out.println("We can't seem to be able to turn in time.");
					Mtocentercirc = Math.sin(angle+addninety)/Math.cos(angle+addninety); // Slope of the line from us to the center of the circle, our angle is a tangent of the circle, so adding 90 degrees, (Math.PI/4) makes it a line that intersects the circle
					System.out.println("Mtocentercirc = " + Mtocentercirc);
					Ctocentercirc = y-(Mtocentercirc*x); // y = mx + c therefore c = y-mx
					System.out.println("CtoCentercirc = " + Ctocentercirc);
					double hyp = Start.distance(x, y, current.x, current.y)/2; // this is the length from us to the line that runs between us and our destination along which any point is equidistant from us and the point we are going
					System.out.println("hyp = " + hyp);
					Mmiddleline = Math.sin(directionto+addninety)/Math.cos(directionto+addninety); // the slope of the line perp to the prev line ^^
					System.out.println("Mmiddleline = " + Mmiddleline);
     				Cmiddleline = (Math.sin(directionto)*hyp+y)-(Mmiddleline*(Math.cos(directionto)*hyp+x));
					System.out.println("Cmiddleline = " + Cmiddleline);
					// Now that we have two lines that run through the center of our optimal circle, we need to find the intersection of these two lines to find the center.
					// m1x + c1 = m2x + c2;
					// x(m1 - m2) = c2 - c1;
					// x = (c2 - c1)/(m1-m2);
					double circx = (Ctocentercirc - Cmiddleline) /(Mmiddleline - Mtocentercirc);
					tcx = circx;
					System.out.println("circx = " + circx);
					// y = mx + c
					double circy = Mmiddleline*circx + Cmiddleline;
					tcy = circy;
					System.out.println("circy = " + circy);
					double circr = Start.distance(x, y, circx, circy);
					tcr = circr;
					System.out.println("circr = " + circr);
					// Now we need to figure out the angle between them
					// |\
					// |A\
					// |  \  r (from earlier that we calculated
				  //hyp|   \ 
					// |    \
					// ------
					// The point that A represents is the center of the circle, r is the radius
					//  angle A is half of the angle between our 2 points and the center of the circle
					double ourangle = Math.asin(hyp/circr)*2; //angle A*2
					System.out.println("ourangle = " + ourangle);
					double percentageofcirc = ourangle/(Math.PI*2); // percentage of the whole circle that ourangleis
					System.out.println("percentageofcirc = " + percentageofcirc);
					double circcirc = Math.PI*circr*2; // the circumfrence of this circle
					System.out.println("circcirc = " + circcirc);
					double distance = circcirc*percentageofcirc; // and the distance around the circle we need to travel
					System.out.println("distance = " + distance);
					double secstocomplete = Math.toDegrees(ourangle)/steer; // time to get to the next point
					System.out.println("secstocomplete = " + secstocomplete);
					double avgspeed = distance/secstocomplete; // therefore the speed we need to be going at
					System.out.println("avgspeed = " + avgspeed);
					System.out.println("speed = " + speed);
					braking = (speed-(avgspeed*2-speed))/secstocomplete;
					System.out.println("braking = " + braking);
				}
				
			}
		}
		GL11.glColor3f(1f,1f,1f);
		GL11.glLineWidth(0.5f);
	    GL11.glBegin(GL11.GL_LINES);
		GL11.glVertex2d(0,Mtocentercirc*0+Ctocentercirc);
		GL11.glVertex2d(1280,Mtocentercirc*1280+Ctocentercirc);
	    GL11.glEnd();
	    GL11.glColor3f(1f,1f,1f);
		GL11.glLineWidth(0.5f);
	    GL11.glBegin(GL11.GL_LINES);
		GL11.glVertex2d(0,Mmiddleline*0+Cmiddleline);
		GL11.glVertex2d(1280,Mmiddleline*1280+Cmiddleline);
	    GL11.glEnd();
	    GL11.glColor3f(0f,0f,1f);
		GL11.glLineWidth(5f);
	    GL11.glBegin(GL11.GL_LINES);
		GL11.glVertex2d(oldx,oldy);
		GL11.glVertex2d(current.x,current.y);
	    GL11.glEnd();
	    GL11.glColor3f(0f,0f,1f);
		GL11.glLineWidth(5f);
	    GL11.glBegin(GL11.GL_LINES);
		GL11.glVertex2d(Math.cos(angle)+oldx,Math.sin(angle)+oldy);
		GL11.glVertex2d(Math.cos(angle)*50+oldx,Math.sin(angle)*50+oldy);
	    GL11.glEnd();
	    st.glCircle3i(tcx, tcy, tcr);
	    double secs2 = 360/steer;
		double circ2 = speed*secs2;
		double radius2 = (circ2/Math.PI)/2;
		//System.out.println(radius2);
		double centerx2,centery2,centerx3,centery3;
		//if(directionto>angle){
			centerx3 = Math.cos(angle+Math.PI/2)*radius2+x;
			centery3 = Math.sin(angle+Math.PI/2)*radius2+y;
		//}else {
			centerx2 = Math.cos(angle-Math.PI/2)*radius2+x;
			centery2 = Math.sin(angle-Math.PI/2)*radius2+y;
		//}
		st.glCircle3i(centerx2,centery2,radius2);
		st.glCircle3i(centerx3,centery3,radius2);
		directionto = Start.dirto(x, y, current.x, current.y);
		
		if((directionto- angle)>Math.PI/180||(directionto-angle)<-Math.PI/180){
			recadjustangle(directionto,0);
			if(directionto>angle){
				angle += Math.min(Math.toRadians(steer*((double)st.getDelta())/1000f), Math.abs(directionto-angle));
			}else{
				angle -= Math.min(Math.toRadians(steer*((double)st.getDelta())/1000f), Math.abs(directionto-angle));
			}
		}
		if(braking!=0){
			speed = Math.max(speed-braking*((double)st.getDelta())/1000f,0);
			if(speed == 0){
				braking = 0;
			}
		} else{
			speed = Math.min(maxspeed, speed+(double)st.getDelta());
		}
		x = x + (double)Math.cos(angle)*speed*((double)st.getDelta())/1000f;
		y = y + (double)Math.sin(angle)*speed*((double)st.getDelta())/1000f;
		if(x>1280) x=0;
		if(y>1024) y=0;
		if(x<0) x = 1280;
		if(y<0) y = 1024;
		/*Vector2f position = super.GetPosition();
		Vector2f screenSize = new Vector2f(768,1024);
		while (position.x > screenSize.x) 
        { position.x -= screenSize.x; }
        while (position.y > screenSize.y) 
        { position.y -= screenSize.y; }
        while (position.x < 0) 
        { position.x += screenSize.x; }
        while (position.y < 0) 
        { position.y += screenSize.y; }
        super.SetLocation(position, super.GetAngle());*/
	}
	public void recadjustangle(double dirto, double ang){
		angle +=ang;
		if(Math.abs(dirto-angle)>Math.PI){
			if(dirto>angle){
				recadjustangle(dirto,(double)Math.PI*2);
			} else{
				recadjustangle(dirto,(double)-Math.PI*2);
			}
		}
	}
	
	public String toString(){
		return "The car " + ID +" is at " + x+ ","+y+" going towards " + current.x +"," +current.y + " at a speed of " + ((speed/w)/0.122) + "mp/h at " + Math.toDegrees(angle) + " degrees \nwith a turning circle of " + (Math.cos(angle+Math.PI/4)*radius+x) + "," + (Math.sin(angle+Math.PI/4)*radius+y) + " and radius " + radius+ " and a top speed of "  + ((maxspeed/w)/0.122) + "mp/h \n and we are braking at a speed of "   + ((braking/w)/0.122) + "mp/h\n";
	}
}
